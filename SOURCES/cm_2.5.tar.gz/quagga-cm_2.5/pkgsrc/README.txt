$Id: README.txt,v 1.1 2004/08/27 15:57:35 gdt Exp $

This directory contains files for use with the pkgsrc framework
(http://www.pkgsrc.org) used with NetBSD and other operating systems.
Eventually it will be hooked into automake such that they can be
installed in /usr/pkg/etc/rc.d (via configure option, probably).

